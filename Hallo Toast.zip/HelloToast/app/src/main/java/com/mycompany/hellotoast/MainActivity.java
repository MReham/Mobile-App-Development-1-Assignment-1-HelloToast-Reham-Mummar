package com.mycompany.hellotoast;

import android.app.*;
import android.os.*;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private int count = 0;
    private TextView displayCountText;
    private Button buttonZero;
    private Button buttonCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        displayCountText = (TextView) findViewById(R.id.text_display_count);
        buttonZero = (Button) findViewById(R.id.button_zero);
        buttonCount = (Button) findViewById(R.id.button_count);

        if (savedInstanceState != null) {
            count = savedInstanceState.getInt("count", 0);
        }
        updateUi();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("count", count);
    }

    public void show_toast(View view) {
        Toast.makeText(this, "Hello Toast", Toast.LENGTH_SHORT).show();
    }

    public void increase_count(View view) {
        count++;
        updateUi();
    }

    public void show_zero(View view) {
        count = 0;
        updateUi();
    }

    private void updateUi() {
        displayCountText.setText(String.valueOf(count));

        if (count == 0) {
            buttonZero.setBackgroundColor(getResources().getColor(R.color.gray));
            buttonCount.setBackgroundColor(getResources().getColor(R.color.blue));
        } else {
            buttonZero.setBackgroundColor(getResources().getColor(R.color.orange));
            if (count % 2 == 1) {
                buttonCount.setBackgroundColor(getResources().getColor(R.color.green));
            } else {
                buttonCount.setBackgroundColor(getResources().getColor(R.color.blue));
            }
        }
    }
}
